if ($("#boot_xs").is(":visible"))
	document.getElementById("scroll_to_here").scrollIntoView();